import {Component, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';

import {ActivatedRoute} from '@angular/router';
import {CdkDragDrop, moveItemInArray} from '@angular/cdk/drag-drop';
import {SortServiceService} from '../sort-service.service';

@Component({
  selector: 'app-input',
  templateUrl: './importName.component.html',
  styleUrls: ['./importName.component.scss']
})

export class ImportNameComponent implements OnInit, OnDestroy {
  constructor(private svc: SortServiceService, private router: Router) {
  }


  currentTasks = {
    taskName: '',
    task: '',
    editing: false,
    id: 2,
  };
  tasks = [];
  ngOnInit() {
    if (localStorage.getItem('tasks')) {
      this.tasks = JSON.parse(localStorage.getItem('tasks'));
  }
  }
// создание задачи
  methodTask() {
    if (this.currentTasks.task.trim() && this.currentTasks.taskName.trim()) {
      this.tasks.push({
        task: this.currentTasks.task,
        taskName: this.currentTasks.taskName,
        editing: false,
        myUrl: '',
        id: this.currentTasks.id++,
      });
      console.log(this.tasks);
    }
  }

// переключатель
  toggleEdit(item) {
    item.editing = true;
  }

// редактирование
  methodEditTask(item) {
    console.log(item);
    if (this.currentTasks.task.trim() && this.currentTasks.taskName.trim()) {
      item.task = this.currentTasks.task;
      item.taskName = this.currentTasks.taskName;
      console.log(this.tasks);
    }
    item.editing = false;
  }
// перетаскиваине
  drop(event: CdkDragDrop<string[]>) {
    moveItemInArray(this.tasks, event.previousIndex, event.currentIndex);
  }

  // добавление картинки
  selectFile(event, item) {
    this.svc.selectFile(event, item);
  }

  logTasks() {
    console.log(this.tasks);
  }

  // Сервисы
  // сортировка по задаче
  sortByTask(args) {
    this.svc.sortByTask(args);
  }
// сортировка по имени задачи
  sortByTaskName(args) {
    this.svc.sortByTaskName(args);
  }
// удаление
  methodRem(index) {
    this.svc.methodRem(this.tasks, index);
  }
// роутинг
  onSelect(item) {
    this.router.navigate(['/task', item.id]);
  }
  ngOnDestroy(): void {
    localStorage.setItem('tasks', JSON.stringify(this.tasks));
    console.log(localStorage);
  }
}

// Сортировка
//   sortByTaskName(tasks){
// tasks.sort((a, b) => a.taskName > b.taskName ? 1 : -1);
//     }
//   sortByTask(tasks){
//     tasks.sort((a, b) => a.task > b.task ? 1 : -1);
//   }
// удаление задачи
//  methodRem(index) {
// //     this.tasks.splice(index, 1);
//   }
// пикча
// selectFile(event, item) {
//
//   const file = event.target.files[0];
//
//   const reader = new FileReader();
//   reader.readAsDataURL(file);
//
//   reader.onload = () => {
//     item.myUrl = reader.result;
//   };
// }
// редактирование
// methodEditTask(item) {
//   console.log(item);
//   if (this.currentTasks.task.trim() && this.currentTasks.taskName.trim()) {
//     item.task = this.currentTasks.task;
//     item.taskName = this.currentTasks.taskName;
//     console.log(this.tasks);
//   }
//
//   item.editing = false;
// }
// Create task
// methodTask() {
//   if (this.currentTasks.task.trim() && this.currentTasks.taskName.trim()) {
//     this.tasks.push({
//       task: this.currentTasks.task,
//       taskName: this.currentTasks.taskName,
//       editing: false,
//       myUrl: '',
//       id: this.currentTasks.id++,
//     });
//     console.log(this.tasks);
//   }
// }
// methodTask() {
//   if (this.currentTasks.task.trim() && this.currentTasks.taskName.trim()) {
//     this.tasks.push({
//       task: this.currentTasks.task,
//       taskName: this.currentTasks.taskName,
//       editing: false,
//       myUrl: '',
//       id: this.currentTasks.id++,
//     });
//     console.log(this.tasks);
//   }
// }
