import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {SortServiceService} from '../sort-service.service';

@Component({
  selector: 'app-home',
  template: `
      <button routerLink="/">На главную</button>
      <h3>Ваша задача: {{tasksId}}</h3>
      <!--  {{tasksId}}-->
      <div *ngFor="let item of sortService.tasks">
          <div *ngIf="item.id == tasksId">
              {{item.task}} | {{item.taskName}}
              <div><img [src]='item.myUrl' *ngIf="item.myUrl"></div>
          </div>
      </div>`
})
export class HomeComponent implements OnInit {
  public tasksId;

  constructor(private activateRoute: ActivatedRoute, public sortService: SortServiceService) {
    // this.id = activateRoute.snapshot.params['id'];
  }

  ngOnInit() {
    const id = parseInt(this.activateRoute.snapshot.paramMap.get('id'));
    this.tasksId = id;
  }
}
